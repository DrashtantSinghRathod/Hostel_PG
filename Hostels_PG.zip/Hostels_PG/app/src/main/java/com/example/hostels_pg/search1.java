package com.example.hostels_pg;

import android.os.Bundle;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class search1 extends AppCompatActivity {
//    ChipGroup cg1, cg2;
//    Chip chip4, chip5, chip6, chip7;
    Spinner spinner5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search1);
//        cg1=findViewById(R.id.cg1);
//        chip4=findViewById(R.id.chip4);
//        chip5=findViewById(R.id.chip5);
//
//        spinner5 = findViewById(R.id.spinner5);
//        chip6=findViewById(R.id.chip6);
//        chip7=findViewById(R.id.chip7);
//
//        cg2=findViewById(R.id.cg2);

    }
}

