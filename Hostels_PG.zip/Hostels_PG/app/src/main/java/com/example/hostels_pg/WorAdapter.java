package com.example.hostels_pg;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class WorAdapter extends ArrayAdapter<UserHostel> {




    private  static final String LOG_TAG=WorAdapter.class.getSimpleName();

    public WorAdapter(Activity context, ArrayList<UserHostel> words) {
        super(context,0,words);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v=convertView;
        if (v==null)
        {
            v=LayoutInflater.from(getContext()).inflate(R.layout.list,parent,false);
        }
        UserHostel user =getItem(position);
        TextView textView22,textView23,textView27,textView21;
        CardView cardView;
        cardView=v.findViewById(R.id.card);
        textView21=v.findViewById(R.id.textView21);
        textView21.setText(user.getType());
        textView22=v.findViewById(R.id.textView22);

        textView22.setText(user.getHname());
        textView23=v.findViewById(R.id.textView23);
        textView23.setText(user.getSrent());
        textView27=v.findViewById(R.id.textView27);
        textView27.setText(user.getFulladd());
        final ImageView imageView3;
        imageView3=v.findViewById(R.id.imageView3);
        FirebaseStorage fs=FirebaseStorage.getInstance();
        String path1="gs://hostelspg.appspot.com/"+user.getPath();
        StorageReference sr=fs.getReferenceFromUrl(path1);
        final long l=1024*1024;
        sr.getBytes(l).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bitmap= BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                ByteArrayOutputStream out=new ByteArrayOutputStream();

                bitmap.compress(Bitmap.CompressFormat.JPEG,8,out);
                imageView3.setImageBitmap(bitmap);


            }
        });


        return v;
    }
}

