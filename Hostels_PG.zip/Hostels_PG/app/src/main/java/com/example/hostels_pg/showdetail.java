package com.example.hostels_pg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.collection.LLRBBlackValueNode;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;

public class showdetail extends AppCompatActivity {
LinearLayout linearLayout4,linearLayout5;
TextView textView1,textView2,textView3,textView4,textView5,textView12,textView17,
        textView22,textView24,textView25,textView26,textView27,textView28,textView29,
        textView32,textView35,textView37,textView38;
ImageView imageView11,imageView12,imageView13,imageView21,imageView22,imageView23,
          imageView31,imageView32,imageView33,imageView41,imageView42,imageView43;
DatabaseReference reference;



int i;
ImageView[] iv1;

ImageView[] iv2;
ImageView[] iv3;
ImageView[] iv4;
String uid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showdetail);

        linearLayout5=findViewById(R.id.linearLayout5);
        linearLayout4=findViewById(R.id.linearLayout4);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        textView12 = findViewById(R.id.textView12);
        textView17 = findViewById(R.id.textView17);
        textView22 = findViewById(R.id.textView22);
        textView24 = findViewById(R.id.textView24);
        textView25 = findViewById(R.id.textView25);
        textView26 = findViewById(R.id.textView26);
        textView27 = findViewById(R.id.textView27);
        textView28 = findViewById(R.id.textView28);
        textView29 = findViewById(R.id.textView29);
        textView32 = findViewById(R.id.textView32);
        textView35 = findViewById(R.id.textView35);
        textView37 = findViewById(R.id.textView37);
        textView38 = findViewById(R.id.textView38);

        imageView11 = findViewById(R.id.imageView11);
        imageView12 = findViewById(R.id.imageView12);
        imageView13 = findViewById(R.id.imageView13);
        imageView21 = findViewById(R.id.imageView21);
        imageView22 = findViewById(R.id.imageView22);
        imageView23 = findViewById(R.id.imageView23);
        imageView31 = findViewById(R.id.imageView31);
        imageView32 = findViewById(R.id.imageView32);
        imageView33 = findViewById(R.id.imageView33);
        imageView41 = findViewById(R.id.imageView41);
        imageView42 = findViewById(R.id.imageView42);
        imageView43 = findViewById(R.id.imageView43);

        iv1= new ImageView[3];
        iv2= new ImageView[3];
        iv3= new ImageView[3];
        iv4= new ImageView[3];

        iv1[0]=imageView11;
        iv1[1]=imageView12;
        iv1[2]=imageView13;

        iv2[0]=imageView21;
        iv2[1]=imageView22;
        iv2[2]=imageView23;

        iv3[0]=imageView31;
        iv3[1]=imageView32;
        iv3[2]=imageView33;

        iv4[0]=imageView41;
        iv4[1]=imageView42;
        iv4[2]=imageView43;

        String type = getIntent().getExtras().getString("type");
        uid = getIntent().getExtras().getString("uid");
        Toast.makeText(this,"welcome to"+type,Toast.LENGTH_LONG).show();
        reference = FirebaseDatabase.getInstance().getReference("Colonies");
        reference.child("colony11").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                UserHostel userHostel = snapshot.getValue(UserHostel.class);
                textView1.setText(userHostel.gender+" Hostel");
                textView2.setText(userHostel.oname);
                textView3.setText(userHostel.hname);
                textView4.setText(userHostel.no1);
                textView5.setText(userHostel.no2);
                textView12.setText(userHostel.srent);
                textView17.setText(userHostel.drent);
                textView22.setText(userHostel.trent);
                textView25.setText(userHostel.fulladd);

                textView26.setText(userHostel.gender+" PG");
                textView27.setText(userHostel.oname);
                textView28.setText(userHostel.no1);
                textView29.setText(userHostel.no2);
                textView32.setText(userHostel.srent);
                textView35.setText(userHostel.drent);
                textView38.setText(userHostel.fulladd);

                FirebaseStorage fs=FirebaseStorage.getInstance();
                StorageReference sr=fs.getReferenceFromUrl("gs://hostelspg.appspot.com/");

                 String[] s={"single/","double/","triple/","pg/"};


                for (final  String t:s){
                    long l=1024*1024;
                    sr.child(uid).child(t).child("1").getBytes(l).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                                if (t.equals("single/"))
                                {
                                    iv1[0].setImageBitmap(bitmap);

                                }
                                if (t.equals("double/"))
                                {
                                    iv2[0].setImageBitmap(bitmap);

                                }
                                if (t.equals("triple/"))
                                {
                                    iv3[0].setImageBitmap(bitmap);

                                }
                                if (t.equals("pg/"))
                                {
                                    iv4[0].setImageBitmap(bitmap);

                                }

                        }
                    });
                    sr.child(uid).child(t).child("2").getBytes(l).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            iv1[1].setImageBitmap(bitmap);
                            if (t.equals("single/"))
                            {
                                iv1[1].setImageBitmap(bitmap);
                            }
                            if (t.equals("double/"))
                            {
                                iv2[1].setImageBitmap(bitmap);

                            }
                            if (t.equals("triple/"))
                            {
                                iv3[1].setImageBitmap(bitmap);

                            }
                            if (t.equals("pg/"))
                            {
                                iv4[1].setImageBitmap(bitmap);

                            }
                        }
                    });

                    sr.child(uid).child(t).child("3").getBytes(l).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            iv1[2].setImageBitmap(bitmap);
                            if (t.equals("single/"))
                            {
                                iv1[2].setImageBitmap(bitmap);

                            }
                            if (t.equals("double/"))
                            {
                                iv2[2].setImageBitmap(bitmap);

                            }
                            if (t.equals("triple/"))
                            {
                                iv3[2].setImageBitmap(bitmap);

                            }
                            if (t.equals("pg/"))
                            {
                                iv4[2].setImageBitmap(bitmap);

                            }
                        }
                    });

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        if (type.equals("HOSTEL"))
        {
            linearLayout5.setVisibility(View.GONE);
            linearLayout4.setVisibility(View.VISIBLE);

        }
        if (type.equals("PG"))
        {
            linearLayout5.setVisibility(View.VISIBLE);
            linearLayout4.setVisibility(View.GONE);
        }
    }

}
