package com.example.hostels_pg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.EventListener;

public class Search extends AppCompatActivity implements AdapterView.OnItemClickListener {
    DatabaseReference reference;
    ArrayList<UserHostel> words=new ArrayList<>();
    ListView list1;
    String  type;
    UserHostel userHostel;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        list1=findViewById(R.id.list1);
        list1.setOnItemClickListener(this);
        FirebaseDatabase fd=FirebaseDatabase.getInstance();
        reference= fd.getReference("Colonies");
        reference.child("colony11").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snapshot1:snapshot.getChildren())
                {
                    UserHostel w=snapshot1.getValue(UserHostel.class);
                    words.add(w);


                }
                WorAdapter adapter=new WorAdapter(Search.this,words);
                list1.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }



    private void layoutAnimation(ListView listView)
    {
        Context context=listView.getContext();
        LayoutAnimationController layoutAnimationController= AnimationUtils.loadLayoutAnimation(context,R.anim.anim);
        listView.setLayoutAnimation(layoutAnimationController);
        listView.getAdapter().notify();
        listView.scheduleLayoutAnimation();


    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        userHostel = words.get(position);
        type = userHostel.getType();
        String uid=userHostel.getUid();
        //Toast.makeText(this,type,Toast.LENGTH_LONG).show();
        Intent intent = new Intent(Search.this,showdetail.class);
        intent.putExtra("type",type);
        intent.putExtra("uid",uid);
        startActivity(intent);
    }
}
