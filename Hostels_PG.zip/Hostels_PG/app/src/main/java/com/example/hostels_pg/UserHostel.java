package com.example.hostels_pg;

public class UserHostel {
    public String uid,path,type,gender,oname,hname,email,no1,no2,srent,drent,trent,detail,fulladd;
    public UserHostel()
    {

    }



    public UserHostel(String uid,String path,String type,String gender, String hname, String oname, String email, String no1, String no2, String srent, String drent, String trent,String detail, String fulladd) {
        this.uid=uid;
        this.gender = gender;
        this.type=type;
        this.path=path;
        this.hname = hname;
        this.oname = oname;
        this.email = email;
        this.no1 = no1;
        this.no2 = no2;
        this.srent = srent;
        this.drent = drent;
        this.trent = trent;

        this.detail = detail;
        this.fulladd = fulladd;

    }


    public String getUid()
    {
        return uid;
    }

    public String getPath() {
        return path;
    }

    public String getType() {
        return type;
    }

    public String getHname() {
        return hname;
    }
    public String getOname()
    {
        return oname;
    }



    public String getSrent() {
        return srent;
    }



    public String getFulladd() {
        return fulladd;
    }

}
